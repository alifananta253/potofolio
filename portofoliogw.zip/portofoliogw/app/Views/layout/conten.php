<?php
 if($conten){
    echo view($conten);
 }
