<div class="credits">

    Designed by <a href="phpcode.id">phpcode.id</a>
</div>

<script src="<?= base_url() ?>assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="<?= base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?= base_url() ?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?= base_url() ?>assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?= base_url() ?>assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="<?= base_url() ?>assets/vendor/php-email-form/validate.js"></script>

<script src="<?= base_url() ?>assets/js/main.js"></script>

</body>

</html>